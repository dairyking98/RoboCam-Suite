x86: 32-bit x86 architecturethe, GCC compiler target is 'i686-linux-gnu' or 'i386-linux-gnu'

x64: also known as x86_64 or amd64, the GCC compiler target is 'x86_64-linux-gnu'

arm32: here as a shorthand for the 32-bit Arm architecture (commonly called Arm in other documentation), the GCC compiler target is 'arm-linux-gnueabihf'

arm64: also commonly called AArch64, the GCC compiler target is 'aarch64-linux-gnu'
